package sg.gov;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import sg.gov.ndi.MyInfoConnector;
import sg.gov.ndi.MyInfoException;
import org.springframework.boot.SpringApplication;

@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class })
@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class })
public class SampleMain {

    public static void main(String[] args) throws MyInfoException {
        SpringApplication.run(SampleMain.class, args);

        //MyInfoConnector connector =
               // MyInfoConnector.getInstance("/Users/saltandsugar/Downloads/myinfo-connector-java-master/MyInfoConnectorTEST.properties");

        //connector = MyInfoConnector.getCurrentInstance();


    }
}

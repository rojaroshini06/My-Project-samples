package sg.gov.ndi;

public class MyInfoException extends Exception {

	private static final long serialVersionUID = 1L;

	public MyInfoException(String message) {
		super(message);
	}

	public MyInfoException() {
		super();
	}

}

package sg.gov.ndi.rest.controller;


import com.sun.xml.internal.messaging.saaj.packaging.mime.MessagingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MissingPathVariableException;
import org.springframework.web.bind.annotation.*;
import sg.gov.ndi.MyInfoConnector;
import sg.gov.ndi.MyInfoException;

import javax.validation.constraints.NotBlank;
import java.util.List;

@CrossOrigin(origins = "http://localhost:3003")
@RestController
@RequestMapping("/myinfo")
public class BookStoreController {

    @Autowired
    BookStoreController bookStoreController;


    @GetMapping("/authcode")
    public String authcode(){
        return "hello";
    }

    @PostMapping("/getCode")
    public String getEmployeeById(@RequestParam String code, @RequestParam String state)throws MyInfoException {
        String txnNo = "500";
        System.out.println(code);
        System.out.println(state);


        MyInfoConnector connector = MyInfoConnector.getInstance("/Users/saltandsugar/Downloads/myinfo-connector-java-master/MyInfoConnectorSANDBOX.properties");

        //connector.getCurrentInstance();

        //bookStoreController.createTokenRequest(code, state, connector);

        String jsondata = connector.getMyInfoPersonData(code,state);


        System.out.println(jsondata.toString());
        return jsondata;

    }

    public void createTokenRequest(String authCode, String state, MyInfoConnector connector)
    {
        //String privateKey = "/Users/saltandsugar/Downloads/myinfo-connector-java-master/src/main/java/resources/ssl/stg-demoapp-client-privatekey-2018.pem";
        //String token = MyInfoConnector.getAccessToken(authCode, connector.getTokenURL(), connector.getClientAppId(), connector.getClientAppPwd(), connector.getRedirectUri(), connector.getEnv(),
             //   privateKey, state, connector.getProxyTokenURL(), connector.getUseProxy());

       // connector.
    }


}

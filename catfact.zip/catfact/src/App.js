import './App.css';
import React, { useState, useEffect } from 'react';

import axios from 'axios';
function App() {
  var authApiUrl = 'https://sandbox.api.myinfo.gov.sg/com/v3/authorise';
  var clientId = 'STG2-MYINFO-SELF-TEST';
  var attributes =
    'uinfin,name,sex,race,nationality,dob,email,mobileno,regadd,housingtype,hdbtype,marital,edulevel,noa-basic,ownerprivate,cpfcontributions,cpfbalances';
  var purpose = 'demonstrating MyInfo APIs';
  var redirectUrl = 'http://localhost:3003/callback';
  var state = '123';

  const getToken = async () => {
    var authoriseUrl =
      authApiUrl +
      '?client_id=' +
      clientId +
      '&attributes=' +
      attributes +
      '&purpose=' +
      purpose +
      '&state=' +
      encodeURIComponent(state) +
      '&redirect_uri=' +
      redirectUrl;

    window.location = authoriseUrl;

    window.onload = function () {
      console.log('yippeeee');
    };

    setTimeout(() => {
      window.location = authoriseUrl;
    }, 60000);

    if (
      this.location.href.includes('callback?') &&
      this.location.href.includes('code=')
    ) {
      //	scrollToAppForm = true;

      // call the backend server APIs
      console.log('yippeeee');
    }

    //const response = await fetch(authoriseUrl);
    //const data = await response.data;
    //setToken(data.access_token);
  };

  //const handleClick = () => {
  //fetchFact();
  //};

  function callAuthoriseApi(e) {
    console.log('You clicked callAuthoriseApi.');
    var authoriseUrl =
      authApiUrl +
      '?client_id=' +
      clientId +
      '&attributes=' +
      attributes +
      '&purpose=' +
      purpose +
      '&state=' +
      encodeURIComponent(state) +
      '&redirect_uri=' +
      redirectUrl;

    window.location = authoriseUrl;
  }

  useEffect(() => {
    window.addEventListener('load', temp);
  });

  function temp() {
    console.log('yippeeee');
    if (
      this.location.href.includes('callback?') &&
      this.location.href.includes('code=')
    ) {
      //	scrollToAppForm = true;

      // call the backend server APIs
      console.log('okkkkkkkkkkkk');
      console.log(this.location.href);

      var url = new URL(this.location.href);
      var code = url.searchParams.get('code');
      var state = url.searchParams.get('state');

      //axios.get('http://localhost:8091/myinfo/authcode').then(response => {
      // console.log(response.data);
      //});

      axios
        .post('http://localhost:8090/myinfo/getCode', null, {
          params: {
            code: code,
            state: state,
          },
        })
        .then(response => console.log(response.data))
        .catch(err => console.warn(err));
    }
  }

  function handleSubmit(e) {
    e.preventDefault();
    console.log('You clicked submit.');
    //callAuthoriseApi();
    getToken();
  }

  return (
    <div className="App">
      <body onload="myFunction()"></body>
      <h2>myInfo </h2>
      <hr />
      <form onSubmit={handleSubmit}>
        <button type="submit">Retrieve myInfo details</button>
      </form>
    </div>
  );
}
export default App;
